---
name: motive-v3d-biomech-guidelines
description: Motive(OptiTrack) Conventional 39 marker set(+medial marker) 기반 C3D 데이터를 Visual3D(V3D) 방식으로 해석/분석하기 위한 오프라인 가이드. 사용자 데이터 규칙(파일명/좌표계/이벤트/분석 구간) + V3D에서 가능한 marker-only 생체역학(COM, XCoM, BoS, MoS 등) 분석 절차를 정리한다.
---

# Motive OptiTrack Marker set & Visual3D 분석 가이드

이 스킬은 **(1) OptiTrack Motive Conventional(39) + custom medial marker 구성의 의미를 이해하고**,  
**(2) Visual3D에서 forceplate 없이(marker-only) 가능한 분석을 설계**하며,  
**(3) COM / XCoM / BoS / MoS 계산을 위한 입력·좌표·이벤트·품질관리 규칙**을 한 번에 정리해준다.

> 이 스킬은 “웹 검색 없이” 사용할 수 있도록, 필요한 정의/절차/체크리스트를 스킬 본문에 포함한다.  
> 단, 논문/튜토리얼 원문이 필요하면 References 섹션의 문헌 키워드를 사용해도 된다(필수 아님).

---

## 0) 이 스킬이 트리거되는 상황

다음 질문/작업에서 이 스킬을 먼저 로드한다.

- “Motive OptiTrack Conventional 39 marker set이 뭐였지?”
- “medial marker(RUArm_3 같은 것) 어떻게 쓰지?”
- “내 C3D 좌표계가 X가 -X라는데, MoS 방향성은 어떻게 잡아?”
- “Visual3D 방식으로 marker-only에서 가능한 분석 뭐가 있지?”
- “COM/XCoM/BoS/MoS 계산 전에 필요한 입력이 뭐지?”

그리고 실제 산출(COM, xCOM, BoS, MoS)은 **`v3d-com-bos-xcom-mos` 스킬**(파이프라인)에서 수행한다.

---

## 1) 사용자 데이터 규칙(프로젝트 공통)

### 1.1 C3D 파일 네이밍 규칙

- 규칙: `{date}_{name_initial}_perturb_{velocity}_{trial}.c3d`
- 예: `251112_KUO_perturb_60_001.c3d`

이 규칙을 쓰는 이유:
- 이벤트 파일(perturb_inform.xlsm)에서 **subject / velocity / trial**로 이벤트를 찾기 쉽다.
- 같은 subject의 여러 trial을 자동 처리하기 좋다.

### 1.2 Units / 좌표계(반드시 명시)

- 단위: **meter**
- 좌표(Visual3D 기준으로 해석):

| 축 | 의미 | 부호 규칙(권장 해석) |
|---|---|---|
| X | A/P (전후) | **전방(Anterior) = -X**, 후방(Posterior) = +X |
| Y | R/L (좌우) | 일반적으로 +Y = left, -Y = right (실험실 정의에 따라 확인) |
| Z | Up/Down (수직) | **위(Up) = +Z**, 아래(Down) = -Z |

> 핵심: **MoS는 수평면(“X–Y”)에서 계산**하고, **Z는 COM 높이(=pendulum length 추정 등)에만 사용**한다.

### 1.3 분석 구간(perturbation window)

본 프로젝트에서는 관심 구간을 아래로 통일한다.

- 분석 구간(원 프레임 기준):
  - 시작 = `platform_onset - 100 frames`
  - 끝   = `platform_offset + 100 frames`
- 이유: platform onset 전 baseline을 확보(100 frames)하고, perturbation 종료 이후 회복을 포함(100 frames)한다.

---

## 2) 이벤트 규칙(perturb_inform.xlsm)

### 2.1 이벤트 파일

- 파일: `perturb_inform.xlsm`
- 시트: `platform`
- 주요 컬럼(필수):  
  - `subject`, `velocity`, `trial`
  - `platform_onset`, `platform_offset`
  - `step_onset` (step trial에서만 있을 수 있음)
  - `state` (예: `step_L`, `step_R`, `nonstep`, `footlift` 등)

### 2.2 이벤트의 해석(분석 로직에 직접 영향)

- `platform_onset`: perturbation이 시작된 프레임(가장 중요한 기준점)
- `platform_offset`: perturbation 종료 프레임
- `step_onset`: 발을 들어 “step” 반응이 시작된 프레임(있을 수도, 없을 수도)
- `state`:
  - `step_L`라면 **왼발이 stepping foot**(대체로 오른발이 stance로 남는다)로 해석한다.
  - `step_R`라면 반대.
  - `nonstep`/`footlift`는 보통 step_onset이 비어있고, double support(또는 미세한 언로딩)로 처리한다.

> 실제 BoS 계산에서 “double vs single support”를 나누는 기준은 **step_onset 유무**와 **step_onset 이후 어느 발이 지지발인지**이다.

---

## 3) Marker set 설명: OptiTrack Conventional 39 + custom medial

### 3.1 포함 파일(스킬에 동봉)

- `references/optitrack_marker_context.xml`  
  - Conventional 39 marker의 세그먼트 구성과,
  - **사용자 커스텀 medial marker**(예: `LUArm_3`, `LShin_3`, `LFoot_3`)의 의미/대응관계를 설명한다.

### 3.2 커스텀 medial markers(분석에 “반드시” 활용)

본 프로젝트에서는 다음 medial marker를 적극 사용한다(관절 중심/축, 발 폭/BoS 등에서 중요).

| 부위 | lateral (기본) | medial (custom) | 의미 |
|---|---|---|---|
| Elbow | `LELB` / `RELB` | `LUArm_3` / `RUArm_3` | elbow axis를 더 잘 정의 |
| Knee | `LKNE` / `RKNE` | `LShin_3` / `RShin_3` | knee joint center 근사(좌우 epicondyle midpoint) |
| Ankle | `LANK` / `RANK` | `LFoot_3` / `RFoot_3` | ankle center 및 foot width 방향 정의 |

> 특히 **발(foot) 관련 계산(BoS/MoS)**에서 medial marker를 빼면 발 폭/경계가 축소되거나 방향 추정이 불안정해진다.

### 3.3 Marker-only에서 가능한 V3D 분석(Forceplate 1개 → 미사용)

본 프로젝트는 forceplate를 신뢰할 수 없으므로(또는 single plate로 불충분) 다음 범주 위주로 설계한다.

가능(추천):
- **COM / segment COM / whole-body COM**
- **COM velocity / acceleration**
- **XCoM(xCOM) / MoS(=Margin of Stability)**
- 관절 위치/각도 기반의 kinematics(자세, joint angles 등)  
- step timing 기반 spatiotemporal: step latency, step length(마커로), recovery time 등

불가(또는 비추천):
- GRF 기반 kinetics(관절 모멘트/파워)
- COP 기반 안정성(정확한 COP는 forceplate 필요)

---

## 4) Visual3D 튜토리얼 로직으로 안정성 지표 만들기(핵심)

본 프로젝트의 목표는 V3D 튜토리얼 로직을 그대로 따른다:

1) **XCoM 계산(Hof)**  
2) **foot landmark 기반 BoS 폴리곤**  
3) **BoS boundary까지 거리로 MoS**  

(정의/기호는 문헌마다 약간 다르지만 핵심은 동일)

### 4.1 XCoM (Extrapolated CoM / Hof)

- 개념: inverted pendulum 모델에서 **COM 위치 + COM 속도 항**을 합친 “동적” COM
- 수식(수평면 기준):
  - `xCoM_xy = CoM_xy + vCoM_xy / ω0`
  - `ω0 = sqrt(g / l)`
  - `g = 9.81 m/s^2`
  - `l = pendulum length` → 실무에서는 보통 **leg length** 또는 baseline의 COM 높이 근사

프로젝트 규칙(중요):
- **신체계측(leg length)이 있으면 반드시 그 값을 사용**한다.
- leg length가 없으면 분석 정확도가 떨어지므로, 파이프라인 스킬에서 사용자에게 요청한다.

### 4.2 BoS (Base of Support) 폴리곤

Forceplate COP를 못 쓰는 경우, marker로 BoS를 구성한다.

- 각 발에서 최소 landmark(권장):
  - heel(뒤), toe(앞), ankle lateral(가쪽), ankle medial(안쪽)
- Double support:
  - 양발 landmark를 합쳐 polygon(일반적으로 convex hull 사용)
- Single support(stepping 이후):
  - 지지발(stance foot) landmark만 사용

팁:
- toe marker가 발끝이 아니라면(=중족 부위) **foot length anthropometric**으로 “가상 발끝점”을 생성하면 경계가 더 현실적이다.

### 4.3 MoS (Margin of Stability)

MoS는 “xCoM이 BoS 안에 얼마나 깊게 들어와 있는가(또는 밖으로 얼마나 나갔는가)”를 나타낸다.

실무적 정의(2D polygon):
- **signed distance**:
  - xCoM이 polygon 내부면 +distance(경계까지 최소거리)
  - 외부면 -distance(외부로 나간 거리)
- 방향성 MoS(optional):
  - COM velocity 방향으로 ray를 쏘아 boundary까지의 거리를 구하면 “진행 방향 안정 여유”가 된다.

프로젝트에서는 보통 다음을 함께 산출하면 해석이 쉬움:
- `MOS_signed_minDist` (inside/outside 판정에 강함)
- `MOS_AP_dir` (전후 방향)
- `MOS_ML_dir` (좌우 방향)
- `MOS_dir2D` (COM 속도 방향 기반)

---

## 5) 입력 체크리스트(분석 실행 전)

다음이 없으면, 계산을 진행하지 말고 사용자에게 먼저 요청한다.

### 5.1 필수 파일
- C3D (marker-only): `{date}_{initial}_perturb_{velocity}_{trial}.c3d`
- 이벤트: `perturb_inform.xlsm` (platform 시트)

### 5.2 필수 신체계측(최소)
- **leg length** (cm 또는 m)
- **foot length** (mm 또는 m) — 가능하면 L/R
- **foot width** (cm 또는 m) — 가능하면 L/R
- **ankle width** (cm 또는 m) — 가능하면 L/R

> 위 계측치가 없으면 XCoM의 ω0(l)과 BoS 경계(가상 발끝/폭)가 부정확해져 MoS 해석이 흔들린다.

### 5.3 (선택) V3D COM 비교 파일
- Visual3D에서 export한 COM(`*_COM.xlsx`)가 있으면, 파이프라인 결과와 **상관계수/오차**를 계산해 QA를 한다.

---

## 6) 품질관리(QA) 권장 기준

- COM 비교(Visual3D vs Python):
  - 축별 corr가 **1에 매우 근접(예: ≥ 0.995)** 해야 함
  - RMSE가 수 cm 수준(예: ≤ 0.02 m) 이내면 보통 매우 양호
- foot marker 기반 heel-to-toe 거리 vs 신체계측 foot length:
  - 큰 차이가 나면 toe marker 위치(발끝 vs 중족) 또는 labeling 문제를 의심한다.

---

## 7) 다음 단계: 실제 산출(계산)로 넘어가기

실제 COM/XCoM/BoS/MoS 계산과 엑셀 출력은 아래 스킬을 사용한다.

- **`v3d-com-bos-xcom-mos` 스킬**: marker-only C3D → timeseries/summary Excel 생성 + V3D COM 검증

---

## References (읽을거리; 이 스킬만으로도 분석 가능)

- Hof의 XCoM/MoS 개념(원전): “The condition for dynamic stability” (Hof et al.)  
- Visual3D(Has-Motion) MoS 튜토리얼: “Assessing Stability During Gait”  
- Hip joint center 회귀식: Harrington et al. (HJC prediction)
