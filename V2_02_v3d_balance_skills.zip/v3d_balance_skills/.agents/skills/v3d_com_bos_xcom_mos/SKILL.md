---
name: v3d-com-bos-xcom-mos
description: Visual3D 튜토리얼 로직(1) XCoM(Hof) + (2) foot landmark 기반 BoS polygon + (3) boundary distance 기반 MoS)을 marker-only C3D에 그대로 적용해 COM, XCoM, BoS, MoS를 산출한다. perturb_inform.xlsm(platform 시트) 이벤트를 사용하며, 신체계측(leg/foot/ankle)을 반드시 요구한다. 결과는 Excel(timeseries/summary/COM_compare)로 출력한다.
---

# Visual3D 방식 COM / XCoM / BoS / MoS 파이프라인

이 스킬은 **marker-only C3D**에서 다음 변인을 계산해 엑셀로 저장한다.

- Whole-body **COM** (link-model based)
- **XCoM (xCOM)** (Hof; inverted pendulum 기반 extrapolated CoM)
- **BoS (Base of Support)** polygon (foot landmark 기반)
- **MoS (Margin of Stability)** (BoS boundary까지 거리; signed + directional)

또한 Visual3D에서 export한 COM과 비교해 **corr/RMSE QA**를 수행한다(권장).

---

## 0) 시작 전: 입력 요구사항(없으면 반드시 사용자에게 요청)

### 0.1 필수 파일
- C3D: `{date}_{initial}_perturb_{velocity}_{trial}.c3d`
- 이벤트: `perturb_inform.xlsm` (sheet: `platform`)

### 0.2 필수 신체계측(이 스킬은 “없으면 멈춘다”)
다음 값이 없으면, **분석을 진행하지 말고** 사용자에게 받는다.

- leg length (cm 또는 m)
- foot length (mm 또는 m) — 가능하면 left/right
- foot width (cm 또는 m) — 가능하면 left/right
- ankle width (cm 또는 m) — 가능하면 left/right

사용자에게 요청할 때는 아래 템플릿을 그대로 써도 된다.

```text
분석을 위해 신체계측이 필요합니다(없으면 XCoM/BoS가 부정확).
- leg length (cm): 
- foot length L/R (mm): 
- foot width L/R (cm): 
- ankle width L/R (cm):
```

### 0.3 (권장) Visual3D COM export
- `*_COM.xlsx` (Visual3D의 LINK_MODEL_BASED::ORIGINAL::COM export)
- 목적: 계산된 COM이 Visual3D 결과와 **상관계수 1에 근접**하는지 검증

---

## 1) V3D 튜토리얼 로직(요약)

1) **XCoM 계산(Hof)**  
   - `xCoM_xy = CoM_xy + vCoM_xy / sqrt(g/l)`
2) **BoS 폴리곤**
   - 발 landmark(heel/toe + ankle lateral/medial)로 polygon 구성
3) **MoS**
   - xCoM이 BoS 내부면 +, 외부면 - 로 signed distance
   - (옵션) COM 속도 방향으로 boundary까지 ray distance(MOS_dir2D)

> 좌표계 해석/marker 의미는 `motive-v3d-biomech-guidelines` 스킬을 함께 참조.

---

## 2) 계산 절차(권장 워크플로우)

### Step A — 파일/이벤트 로딩
1. C3D filename에서 `date, initial, velocity, trial` 파싱  
2. `perturb_inform.xlsm`의 `platform` 시트에서  
   `subject + velocity + trial`로 행을 찾아 `platform_onset/offset`, `step_onset`, `state` 확보
3. 분석 window를 `[onset-100, offset+100]`로 설정해 trim  
4. local frame(=trim 후 frame) 기준으로 onset/offset/step_onset 재계산  
5. 출력 Excel에는 `Original_frame`(원 프레임)도 유지

### Step B — COM / COM velocity
- marker 기반 15-link whole-body COM 계산  
- COM velocity는 수치미분(gradient)  
- hip joint center는 Harrington 등 회귀식 기반(가능한 경우)

### Step C — XCoM (Hof)
- 입력 leg length를 m로 변환(>10이면 cm로 간주)  
- `ω0 = sqrt(g/l)`  
- `xCoM_xy = CoM_xy + vCoM_xy / ω0`

### Step D — BoS polygon
- 각 프레임마다 지원 상태 결정:
  - step_onset이 없으면 전 구간 double support
  - step_onset 이후에는 `state(step_L/step_R)`에 따라 stance foot만 사용
- BoS landmark(예):
  - heel: `LHEE/RHEE`
  - toe: `LTOE/RTOE`
  - ankle lateral: `LANK/RANK`
  - ankle medial(custom): `LFoot_3/RFoot_3`
- (권장) toe marker가 발끝이 아니면, anthropometric foot length로 “virtual toe tip” 생성

### Step E — MoS
- `MOS_signed_minDist`: polygon 내부=+, 외부=- 최소거리
- `MOS_dir2D`: COM velocity 방향 ray로 boundary 교차점까지 거리(가능하면)
- AP/ML 성분도 함께 산출(해석 편의)

### Step F — 결과 저장 + QA
- timeseries sheet: 프레임별 COM/XCoM/BoS/MoS
- summary sheet: baseline 평균, onset→step 구간 최소값 등 핵심지표
- COM_compare sheet(옵션): Visual3D COM과 비교(corr/RMSE)

---

## 3) 스크립트 실행(기본)

이 스킬 폴더의 `scripts/v3d_mos_pipeline.py`를 사용한다.

### 3.1 최소 실행 예시(anthro 필수)
```bash
python scripts/v3d_mos_pipeline.py   --c3d 251112_KUO_perturb_60_001.c3d   --event_xlsm perturb_inform.xlsm   --subject 김우연   --leg_length 86   --foot_length 240   --foot_width 8.5   --ankle_width 6.5   --v3d_com 251112_KUO_perturb_60_001_COM.xlsx   --out 251112_KUO_perturb_60_001_MOS.xlsx
```

- 단위 자동 인식:
  - `leg_length > 10` → cm로 간주
  - `foot_length > 1` → mm로 간주
  - `foot_width, ankle_width > 1` → cm로 간주

### 3.2 좌/우 발 계측치를 따로 줄 수도 있음(선택)
```bash
python scripts/v3d_mos_pipeline.py   --c3d ...   --event_xlsm ...   --subject ...   --leg_length 0.86   --foot_length_L 240 --foot_length_R 240   --foot_width_L 8.5 --foot_width_R 8.5   --ankle_width_L 6.5 --ankle_width_R 6.5   --out ...
```

---

## 4) 산출물 컬럼(해석 포인트)

- `Time_rel_platform_onset_s`: 0이 platform onset
- `Support`: double / left / right
- `COM_*`, `COMv_*`
- `XCOM_X`, `XCOM_Y` (수평면)
- `MKR_*`: marker-hull 기반 BoS/MoS
- `VIRT_*`: anthropometric virtual foot 기반 BoS/MoS (본 프로젝트의 주 사용값)
- `VIRT_L_heeltoe_len`, `VIRT_R_heeltoe_len`: toe-heel marker 거리(QA용)

---

## 5) 실패/예외 처리 원칙(중요)

- 신체계측이 없으면: **반드시 사용자에게 요청**하고 중단
- 이벤트 행이 없으면:
  - (1) subject/velocity/trial 값이 맞는지 확인 요청
  - (2) 파일명 규칙 불일치면 사용자에게 올바른 velocity/trial을 확인 요청
- marker가 누락되면:
  - `motive-v3d-biomech-guidelines` 스킬을 로드하여 marker 이름/medial marker 매핑을 재확인
  - 필요시, C3D에 실제로 존재하는 marker label 목록을 사용자에게 공유 요청

---

## 6) 이 스킬과 연동되는 다른 스킬

- `motive-v3d-biomech-guidelines`:
  - 좌표계/marker 의미/가능한 분석 범위/필수 입력 체크리스트를 제공
