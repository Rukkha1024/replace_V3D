#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""v3d_mos_pipeline.py

Visual3D tutorial-equivalent (marker-only) pipeline for:
  - Whole-body COM (link-model based)
  - Extrapolated COM (XCoM / xCoM, Hof)
  - Base of Support (BoS) polygon from foot landmarks
  - Margin of Stability (MoS) to BoS boundary (signed + directional)

Key design goals
----------------
- Follow the Visual3D tutorial logic:
    (1) XCoM (Hof) + (2) foot-landmark BoS polygon + (3) distance-to-boundary MoS
- Marker-only workflow (force plate not required / not used).
- Always use subject anthropometrics (required inputs):
    * leg length (for omega0 in Hof XCoM)
    * foot length / width + ankle width (for virtual foot BoS geometry)

Inputs
------
- C3D: marker trajectories (m)   e.g., 251112_KUO_perturb_60_001.c3d
- Events XLSM: perturb_inform.xlsm (sheet 'platform')
- Subject name string must match the 'subject' column in the XLSM.

Outputs
-------
Excel file with:
  - timeseries: COM, COM velocity, XCoM, BoS, MoS (marker-hull + virtual-foot)
  - summary: baseline means, min MoS from platform onset to step onset, etc.
  - COM_compare (optional): correlation/RMSE vs Visual3D COM export

Dependencies
------------
pip install numpy pandas shapely scipy openpyxl ezc3d

Example
-------
python scripts/v3d_mos_pipeline.py \
  --c3d 251112_KUO_perturb_60_001.c3d \
  --event_xlsm perturb_inform.xlsm \
  --subject 김우연 \
  --leg_length 86 \
  --foot_length 240 \
  --foot_width 8.5 \
  --ankle_width 6.5 \
  --v3d_com 251112_KUO_perturb_60_001_COM.xlsx \
  --out 251112_KUO_perturb_60_001_MOS.xlsx

Unit handling
-------------
- leg_length > 10 => cm  (converted to meters)
- foot_length > 1 => mm  (converted to meters)
- foot_width / ankle_width > 1 => cm (converted to meters)

Coordinate conventions (project default)
---------------------------------------
- X: A/P   (forward/anterior = -X)
- Y: M/L   (+Y typically left)
- Z: Vertical (+Z up)

Notes
-----
- This script assumes the event frame numbers in perturb_inform.xlsm refer to the
  original C3D point frames.
- The script trims the trial to [platform_onset-100, platform_offset+100] frames,
  and stores both local frame index and original_frame in the output.
"""

from __future__ import annotations

import argparse
import math
import os
import re
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from shapely.geometry import LineString, MultiPoint, Point as ShPoint

# ezc3d is the simplest robust C3D reader for Python. If missing, fail fast with guidance.
try:
    import ezc3d  # type: ignore
except Exception as e:  # pragma: no cover
    raise ImportError(
        "ezc3d is required to read C3D files. Install with: pip install ezc3d"
    ) from e


# -----------------------------
# Data containers
# -----------------------------
@dataclass
class TrialInfo:
    date: str
    initial: str
    velocity: float
    trial: int


@dataclass
class EventInfo:
    platform_onset: int
    platform_offset: int
    step_onset: Optional[int]
    state: str


@dataclass
class LocalEventInfo:
    trim_start_original_frame: int
    trim_end_original_frame: int
    platform_onset_local: int
    platform_offset_local: int
    step_onset_local: Optional[int]


# -----------------------------
# Helpers: parsing and loading
# -----------------------------
def parse_trial_info(c3d_filename: str) -> TrialInfo:
    """Expected filename rule: {date}_{name_initial}_perturb_{velocity}_{trial}.c3d"""
    base = os.path.basename(c3d_filename)
    m = re.match(
        r"(?P<date>\d{6})_(?P<initial>[A-Za-z]+)_perturb_(?P<vel>\d+(?:\.\d+)?)_(?P<trial>\d+)\.c3d$",
        base,
    )
    if not m:
        raise ValueError(
            f"Filename does not match rule: {base}. Expected: {{date}}_{{initial}}_perturb_{{velocity}}_{{trial}}.c3d"
        )
    return TrialInfo(
        date=m.group("date"),
        initial=m.group("initial"),
        velocity=float(m.group("vel")),
        trial=int(m.group("trial")),
    )


def load_event_info(xlsm_path: str, subject: str, velocity: float, trial: int) -> EventInfo:
    df = pd.read_excel(xlsm_path, sheet_name="platform")
    sel = df[(df["subject"] == subject) & (df["velocity"] == velocity) & (df["trial"] == trial)]
    if sel.empty:
        raise ValueError(
            f"No row found in platform sheet for subject={subject}, velocity={velocity}, trial={trial}. "

            "Check spelling (subject), and that the C3D filename velocity/trial match the sheet."
        )
    row = sel.iloc[0]
    step_onset = None
    if ("step_onset" in row.index) and (not pd.isna(row["step_onset"])):
        step_onset = int(row["step_onset"])
    return EventInfo(
        platform_onset=int(row["platform_onset"]),
        platform_offset=int(row["platform_offset"]),
        step_onset=step_onset,
        state=str(row.get("state", "")),
    )


def compute_local_events(ev: EventInfo, pre: int = 100, post: int = 100) -> LocalEventInfo:
    """Define analysis window and convert event frames into the trimmed local frame index."""
    trim_start = int(ev.platform_onset) - int(pre)
    trim_end = int(ev.platform_offset) + int(post)
    platform_onset_local = int(ev.platform_onset) - trim_start + 1
    platform_offset_local = int(ev.platform_offset) - trim_start + 1
    step_onset_local = int(ev.step_onset) - trim_start + 1 if ev.step_onset is not None else None
    return LocalEventInfo(
        trim_start_original_frame=trim_start,
        trim_end_original_frame=trim_end,
        platform_onset_local=platform_onset_local,
        platform_offset_local=platform_offset_local,
        step_onset_local=step_onset_local,
    )


def _find_label_any(labels: Sequence[str], candidates: Sequence[str]) -> str:
    """Find a marker label by trying multiple suffix candidates.

    Strategy:
    1) exact suffix match of '*_<cand>'
    2) endswith '<cand>'
    3) exact match '<cand>'
    """
    for cand in candidates:
        # common pattern: prefix + '_' + NAME
        for lab in labels:
            if lab.endswith("_" + cand):
                return lab
        for lab in labels:
            if lab.endswith(cand):
                return lab
        if cand in labels:
            return cand
    raise KeyError(
        f"Marker not found. Tried candidates={list(candidates)}. Example labels: {list(labels)[:15]} ..."
    )


def load_c3d_markers(
    c3d_path: str,
    trim_start_original_frame: int,
    trim_end_original_frame: int,
) -> Tuple[Dict[str, np.ndarray], List[str], float, int]:
    """Load marker time series from C3D and trim to [start,end] in original frame numbers.

    Returns
    -------
    marker_ts: dict[label] -> (n_frames_trimmed, 3)
    labels: list[str]
    fs: float
    first_frame: int (original frame number corresponding to data index 0)
    """
    c3d = ezc3d.c3d(c3d_path)
    labels = list(c3d["parameters"]["POINT"]["LABELS"]["value"])
    fs = float(c3d["parameters"]["POINT"]["RATE"]["value"][0])

    # C3D header includes the first frame number.
    # ezc3d exposes it at: c3d['header']['points']['first_frame']
    first_frame = int(c3d["header"]["points"]["first_frame"])

    pts = c3d["data"]["points"]  # (4, n_markers, n_frames)
    xyz = pts[:3, :, :]  # (3, n_markers, n_frames)
    n_frames = xyz.shape[2]

    # Convert original-frame window into 0-based indices.
    start_idx = int(trim_start_original_frame) - first_frame
    end_idx = int(trim_end_original_frame) - first_frame

    if start_idx < 0 or end_idx >= n_frames:
        raise ValueError(
            "Trim window is outside the C3D frame range. "
            f"C3D first_frame={first_frame}, n_frames={n_frames}, "
            f"requested original frames [{trim_start_original_frame}, {trim_end_original_frame}] -> "
            f"indices [{start_idx}, {end_idx}]."
        )

    xyz_trim = xyz[:, :, start_idx : end_idx + 1]  # inclusive

    marker_ts: Dict[str, np.ndarray] = {}
    for i, lab in enumerate(labels):
        # (3, n_frames_trim) -> (n_frames_trim, 3)
        marker_ts[lab] = xyz_trim[:, i, :].T.copy()

    return marker_ts, labels, fs, first_frame


def _to_meters(value: Optional[float], kind: str) -> Optional[float]:
    if value is None:
        return None
    v = float(value)
    if kind == "leg":
        return v / 100.0 if v > 10.0 else v
    if kind == "foot_length":
        return v / 1000.0 if v > 1.0 else v
    if kind in ("foot_width", "ankle_width"):
        return v / 100.0 if v > 1.0 else v
    return v


# -----------------------------
# Biomechanics core
# -----------------------------

def harrington_hip_centers(
    LASI: np.ndarray, RASI: np.ndarray, LPSI: np.ndarray, RPSI: np.ndarray
) -> Tuple[np.ndarray, np.ndarray]:
    """Harrington et al. predictive hip joint center method (pelvis-only form).

    Inputs are pelvis markers in meters.
    Returns left and right hip joint centers in meters.
    """
    origin = (LASI + RASI) / 2.0
    psis_mid = (LPSI + RPSI) / 2.0

    z_axis = LASI - RASI  # +left
    z_axis /= np.linalg.norm(z_axis, axis=1, keepdims=True)

    x_axis = psis_mid - origin  # +posterior
    x_axis /= np.linalg.norm(x_axis, axis=1, keepdims=True)

    y_axis = np.cross(z_axis, x_axis)  # roughly +superior
    y_axis /= np.linalg.norm(y_axis, axis=1, keepdims=True)

    x_axis = np.cross(y_axis, z_axis)
    x_axis /= np.linalg.norm(x_axis, axis=1, keepdims=True)

    # Pelvis width/depth in mm (Harrington regression uses mm)
    PW = np.linalg.norm(LASI - RASI, axis=1) * 1000.0
    PD = np.linalg.norm(origin - psis_mid, axis=1) * 1000.0

    x = -0.24 * PD - 9.9
    y = -0.30 * PW - 10.9
    z = 0.33 * PW + 7.3

    x_m = x / 1000.0
    y_m = y / 1000.0
    z_m = z / 1000.0

    L_offset = x_m[:, None] * x_axis + y_m[:, None] * y_axis + z_m[:, None] * z_axis
    R_offset = x_m[:, None] * x_axis + y_m[:, None] * y_axis - z_m[:, None] * z_axis

    L_HJC = origin + L_offset
    R_HJC = origin + R_offset
    return L_HJC, R_HJC


def compute_whole_body_com(marker_ts: Dict[str, np.ndarray], labels: List[str]) -> np.ndarray:
    """Marker-based 15-link whole-body CoM (segment COM weighted average).

    This is designed to be close to Visual3D's LINK_MODEL_BASED COM for a typical full-body marker set.
    """

    def m(cands: Sequence[str]) -> np.ndarray:
        lab = _find_label_any(labels, cands)
        return marker_ts[lab]

    # --- pelvis
    LASI = m(["LASI", "LIAS"])
    RASI = m(["RASI", "RIAS"])
    LPSI = m(["LPSI", "LIPS"])
    RPSI = m(["RPSI", "RIPS"])

    # --- head
    head = np.mean(
        [
            m(["LFHD", "LAH"]),
            m(["RFHD", "RAH"]),
            m(["LBHD", "LPH"]),
            m(["RBHD", "RPH"]),
        ],
        axis=0,
    )

    pelvis = np.mean([LASI, RASI, LPSI, RPSI], axis=0)

    # --- torso markers (fallbacks included)
    torso = np.mean(
        [
            m(["C7", "CV7"]),
            m(["CLAV", "SJN", "IJ"]),
            m(["T10", "TV7", "T7"]),
            m(["STRN", "SXS", "PX"]),
            m(["RBAK", "TV2", "T2"]),
        ],
        axis=0,
    )

    # Hip joint centers
    L_HJC, R_HJC = harrington_hip_centers(LASI, RASI, LPSI, RPSI)

    # --- upper limbs
    L_sho = m(["LSHO", "LCAJ"])
    R_sho = m(["RSHO", "RCAJ"])

    L_elb_lat = m(["LELB", "LHLE"])
    R_elb_lat = m(["RELB", "RHLE"])
    L_elb_med = m(["LUArm_3", "LHME"])
    R_elb_med = m(["RUArm_3", "RHME"])
    L_elbow = (L_elb_lat + L_elb_med) / 2.0
    R_elbow = (R_elb_lat + R_elb_med) / 2.0

    # wrists
    L_wra = m(["LWRA", "LUSP", "LRSP"])
    L_wrb = m(["LWRB", "LRSP", "LUSP"])
    R_wra = m(["RWRA", "RUSP", "RRSP"])
    R_wrb = m(["RWRB", "RRSP", "RUSP"])
    L_wrist = (L_wra + L_wrb) / 2.0
    R_wrist = (R_wra + R_wrb) / 2.0

    # hand end markers
    L_fin = m(["LFIN", "LHM2"])
    R_fin = m(["RFIN", "RHM2"])

    # --- lower limbs
    L_kne_lat = m(["LKNE", "LFLE"])
    R_kne_lat = m(["RKNE", "RFLE"])
    L_kne_med = m(["LShin_3", "LFME"])
    R_kne_med = m(["RShin_3", "RFME"])
    L_knee = (L_kne_lat + L_kne_med) / 2.0
    R_knee = (R_kne_lat + R_kne_med) / 2.0

    L_ank_lat = m(["LANK", "LFAL"])
    R_ank_lat = m(["RANK", "RFAL"])
    L_ank_med = m(["LFoot_3", "LTAM"])
    R_ank_med = m(["RFoot_3", "RTAM"])
    L_ank = (L_ank_lat + L_ank_med) / 2.0
    R_ank = (R_ank_lat + R_ank_med) / 2.0

    # --- segment COM location fractions (prox->dist)
    upper_f = 0.436
    fore_f = 0.430
    hand_f = 0.506
    thigh_f = 0.433
    shank_f = 0.433
    foot_f = 0.5

    L_upper = L_sho + upper_f * (L_elbow - L_sho)
    R_upper = R_sho + upper_f * (R_elbow - R_sho)
    L_fore = L_elbow + fore_f * (L_wrist - L_elbow)
    R_fore = R_elbow + fore_f * (R_wrist - R_elbow)
    L_hand = L_wrist + hand_f * (L_fin - L_wrist)
    R_hand = R_wrist + hand_f * (R_fin - R_wrist)

    L_thigh = L_HJC + thigh_f * (L_knee - L_HJC)
    R_thigh = R_HJC + thigh_f * (R_knee - R_HJC)
    L_shank = L_knee + shank_f * (L_ank - L_knee)
    R_shank = R_knee + shank_f * (R_ank - R_knee)

    # foot COM based on heel->toe
    L_heel = m(["LHEE", "LFCC"])
    R_heel = m(["RHEE", "RFCC"])
    L_toe = m(["LTOE", "LFM2"])
    R_toe = m(["RTOE", "RFM2"])
    L_foot = L_heel + foot_f * (L_toe - L_heel)
    R_foot = R_heel + foot_f * (R_toe - R_heel)

    # segment mass fractions (classic 15-link model)
    w = {
        "head": 0.081,
        "pelvis": 0.142,
        "torso": 0.355,
        "L_upper": 0.028,
        "R_upper": 0.028,
        "L_fore": 0.016,
        "R_fore": 0.016,
        "L_hand": 0.006,
        "R_hand": 0.006,
        "L_thigh": 0.100,
        "R_thigh": 0.100,
        "L_shank": 0.0465,
        "R_shank": 0.0465,
        "L_foot": 0.0145,
        "R_foot": 0.0145,
    }

    seg = {
        "head": head,
        "pelvis": pelvis,
        "torso": torso,
        "L_upper": L_upper,
        "R_upper": R_upper,
        "L_fore": L_fore,
        "R_fore": R_fore,
        "L_hand": L_hand,
        "R_hand": R_hand,
        "L_thigh": L_thigh,
        "R_thigh": R_thigh,
        "L_shank": L_shank,
        "R_shank": R_shank,
        "L_foot": L_foot,
        "R_foot": R_foot,
    }

    com = np.zeros_like(head)
    total = float(sum(w.values()))
    for k, wk in w.items():
        com += wk * seg[k]
    com /= total
    return com


def compute_xcom(
    com: np.ndarray,
    fs: float,
    leg_length_m: float,
    g: float = 9.81,
) -> Tuple[np.ndarray, np.ndarray, float, float]:
    """Hof XCoM on horizontal plane (X,Y)."""
    dt = 1.0 / fs
    com_vel = np.gradient(com, dt, axis=0)

    l = float(leg_length_m)
    if not (l > 0):
        raise ValueError(f"leg_length_m must be >0. Got: {leg_length_m}")

    omega0 = math.sqrt(g / l)

    xcom = com.copy()
    xcom[:, 0:2] = com[:, 0:2] + com_vel[:, 0:2] / omega0
    return xcom, com_vel, l, omega0


# -----------------------------
# BoS + MoS
# -----------------------------

def _support_state(i: int, ev_local: LocalEventInfo, state: str) -> str:
    """Return 'double' or single stance side after step onset.

    Convention:
    - Before step_onset: double support.
    - After step_onset:
        state == 'step_L' => left is stepping foot => stance is right
        state == 'step_R' => right is stepping foot => stance is left
    """
    if ev_local.step_onset_local is None:
        return "double"
    if i < ev_local.step_onset_local - 1:
        return "double"
    if state == "step_L":
        return "right"
    if state == "step_R":
        return "left"
    return "double"


def _ray_intersection_distance(poly, xy: np.ndarray, vel_xy: np.ndarray) -> float:
    """Distance from point to polygon boundary along velocity direction (ray)."""
    v = np.asarray(vel_xy, dtype=float)
    norm = float(np.linalg.norm(v))
    if norm < 1e-8:
        return float("nan")
    d = v / norm

    p0 = np.asarray(xy, dtype=float)
    p1 = p0 + d * 10.0  # long enough
    line = LineString([tuple(p0), tuple(p1)])
    inter = poly.boundary.intersection(line)

    pts = []
    if inter.is_empty:
        pts = []
    elif inter.geom_type == "Point":
        pts = [inter]
    else:
        try:
            pts = list(inter.geoms)
        except Exception:
            pts = []

    t_pos = []
    for pt in pts:
        arr = np.array([pt.x, pt.y])
        t = float(np.dot(arr - p0, d))
        if t > 1e-9:
            t_pos.append(t)

    if not t_pos:
        return float("nan")
    return float(min(t_pos))


def compute_bos_mos_marker_hull(
    marker_ts: Dict[str, np.ndarray],
    labels: List[str],
    xcom: np.ndarray,
    com_vel: np.ndarray,
    ev_local: LocalEventInfo,
    state: str,
) -> pd.DataFrame:
    """BoS/MoS using convex hull of actual marker landmarks."""

    def m(cands: Sequence[str]) -> np.ndarray:
        return marker_ts[_find_label_any(labels, cands)]

    n = xcom.shape[0]

    # Prefer medial marker for ankle width definition
    left_pts_xy = [
        m(["LHEE", "LFCC"])[:, 0:2],
        m(["LTOE", "LFM2"])[:, 0:2],
        m(["LANK", "LFAL"])[:, 0:2],
        m(["LFoot_3", "LTAM"])[:, 0:2],
    ]
    right_pts_xy = [
        m(["RHEE", "RFCC"])[:, 0:2],
        m(["RTOE", "RFM2"])[:, 0:2],
        m(["RANK", "RFAL"])[:, 0:2],
        m(["RFoot_3", "RTAM"])[:, 0:2],
    ]

    out = {
        "BOS_area_m2": np.full(n, np.nan),
        "BOS_minX": np.full(n, np.nan),
        "BOS_maxX": np.full(n, np.nan),
        "BOS_minY": np.full(n, np.nan),
        "BOS_maxY": np.full(n, np.nan),
        "MOS_signed_minDist": np.full(n, np.nan),
        "MOS_dir2D": np.full(n, np.nan),
        "MOS_AP_forward": np.full(n, np.nan),
        "MOS_AP_backward": np.full(n, np.nan),
        "MOS_AP_dir": np.full(n, np.nan),
        "MOS_ML_left": np.full(n, np.nan),
        "MOS_ML_right": np.full(n, np.nan),
        "MOS_ML_dir": np.full(n, np.nan),
    }

    for i in range(n):
        feet = _support_state(i, ev_local, state)

        pts = []
        if feet in ("double", "left"):
            pts.extend([tuple(arr[i]) for arr in left_pts_xy])
        if feet in ("double", "right"):
            pts.extend([tuple(arr[i]) for arr in right_pts_xy])

        hull = MultiPoint(pts).convex_hull
        if hull.geom_type != "Polygon":
            continue
        poly = hull

        out["BOS_area_m2"][i] = poly.area
        minx, miny, maxx, maxy = poly.bounds
        out["BOS_minX"][i] = minx
        out["BOS_maxX"][i] = maxx
        out["BOS_minY"][i] = miny
        out["BOS_maxY"][i] = maxy

        p = ShPoint(float(xcom[i, 0]), float(xcom[i, 1]))
        inside = poly.contains(p) or poly.touches(p)
        if inside:
            out["MOS_signed_minDist"][i] = poly.exterior.distance(p)
        else:
            out["MOS_signed_minDist"][i] = -p.distance(poly)

        # directional MoS
        ddir = _ray_intersection_distance(poly, xcom[i, 0:2], com_vel[i, 0:2])
        if inside and not math.isnan(ddir):
            out["MOS_dir2D"][i] = ddir
        else:
            out["MOS_dir2D"][i] = out["MOS_signed_minDist"][i]

        # Direction conventions: forward is -X (anterior boundary = minX)
        out["MOS_AP_forward"][i] = xcom[i, 0] - minx
        out["MOS_AP_backward"][i] = maxx - xcom[i, 0]
        out["MOS_AP_dir"][i] = out["MOS_AP_forward"][i] if com_vel[i, 0] < 0 else out["MOS_AP_backward"][i]

        # ML: +Y typically left => left boundary = maxY
        out["MOS_ML_left"][i] = maxy - xcom[i, 1]
        out["MOS_ML_right"][i] = xcom[i, 1] - miny
        out["MOS_ML_dir"][i] = out["MOS_ML_left"][i] if com_vel[i, 1] > 0 else out["MOS_ML_right"][i]

    return pd.DataFrame(out)


def compute_bos_mos_virtual(
    marker_ts: Dict[str, np.ndarray],
    labels: List[str],
    xcom: np.ndarray,
    com_vel: np.ndarray,
    ev_local: LocalEventInfo,
    state: str,
    foot_length_L_m: float,
    foot_length_R_m: float,
    foot_width_L_m: float,
    foot_width_R_m: float,
    ankle_width_L_m: float,
    ankle_width_R_m: float,
) -> Tuple[pd.DataFrame, np.ndarray, np.ndarray]:
    """BoS/MoS using a virtual foot rectangle-ish boundary.

    Returns
    -------
    df: BoS/MoS
    heeltoe_len_L: (n,) actual marker heel-to-toe length
    heeltoe_len_R: (n,) actual marker heel-to-toe length
    """

    def m(cands: Sequence[str]) -> np.ndarray:
        return marker_ts[_find_label_any(labels, cands)]

    n = xcom.shape[0]
    out = {
        "BOS_area_m2": np.full(n, np.nan),
        "BOS_minX": np.full(n, np.nan),
        "BOS_maxX": np.full(n, np.nan),
        "BOS_minY": np.full(n, np.nan),
        "BOS_maxY": np.full(n, np.nan),
        "MOS_signed_minDist": np.full(n, np.nan),
        "MOS_dir2D": np.full(n, np.nan),
        "MOS_AP_forward": np.full(n, np.nan),
        "MOS_AP_backward": np.full(n, np.nan),
        "MOS_AP_dir": np.full(n, np.nan),
        "MOS_ML_left": np.full(n, np.nan),
        "MOS_ML_right": np.full(n, np.nan),
        "MOS_ML_dir": np.full(n, np.nan),
    }

    heel_L = m(["LHEE", "LFCC"])
    toe_L = m(["LTOE", "LFM2"])
    heel_R = m(["RHEE", "RFCC"])
    toe_R = m(["RTOE", "RFM2"])

    heeltoe_len_L = np.linalg.norm(toe_L[:, 0:2] - heel_L[:, 0:2], axis=1)
    heeltoe_len_R = np.linalg.norm(toe_R[:, 0:2] - heel_R[:, 0:2], axis=1)

    for i in range(n):
        feet = _support_state(i, ev_local, state)
        pts = []

        def add_foot(side: str):
            if side == "L":
                heel = heel_L[i, 0:2]
                toe = toe_L[i, 0:2]
                lat = m(["LANK", "LFAL"])[i, 0:2]
                med = m(["LFoot_3", "LTAM"])[i, 0:2]
                foot_length_m = foot_length_L_m
                foot_width_m = foot_width_L_m
                ankle_width_m = ankle_width_L_m
            else:
                heel = heel_R[i, 0:2]
                toe = toe_R[i, 0:2]
                lat = m(["RANK", "RFAL"])[i, 0:2]
                med = m(["RFoot_3", "RTAM"])[i, 0:2]
                foot_length_m = foot_length_R_m
                foot_width_m = foot_width_R_m
                ankle_width_m = ankle_width_R_m

            # AP axis along heel->toe
            ap = toe - heel
            ap_norm = float(np.linalg.norm(ap))
            if ap_norm < 1e-8:
                return
            ap_u = ap / ap_norm

            # ML axis from medial->lateral (roughly)
            latv = lat - med
            lat_norm = float(np.linalg.norm(latv))
            if lat_norm < 1e-8:
                lat_u = np.array([-ap_u[1], ap_u[0]])
            else:
                lat_u = latv / lat_norm

            # virtual toe tip
            toe_tip = heel + ap_u * foot_length_m

            hw = ankle_width_m / 2.0
            fw = foot_width_m / 2.0

            pts.extend(
                [
                    tuple(heel + lat_u * hw),
                    tuple(heel - lat_u * hw),
                    tuple(toe_tip + lat_u * fw),
                    tuple(toe_tip - lat_u * fw),
                ]
            )

        if feet in ("double", "left"):
            add_foot("L")
        if feet in ("double", "right"):
            add_foot("R")

        if len(pts) < 3:
            continue

        hull = MultiPoint(pts).convex_hull
        if hull.geom_type != "Polygon":
            continue
        poly = hull

        out["BOS_area_m2"][i] = poly.area
        minx, miny, maxx, maxy = poly.bounds
        out["BOS_minX"][i] = minx
        out["BOS_maxX"][i] = maxx
        out["BOS_minY"][i] = miny
        out["BOS_maxY"][i] = maxy

        p = ShPoint(float(xcom[i, 0]), float(xcom[i, 1]))
        inside = poly.contains(p) or poly.touches(p)
        if inside:
            out["MOS_signed_minDist"][i] = poly.exterior.distance(p)
        else:
            out["MOS_signed_minDist"][i] = -p.distance(poly)

        ddir = _ray_intersection_distance(poly, xcom[i, 0:2], com_vel[i, 0:2])
        if inside and not math.isnan(ddir):
            out["MOS_dir2D"][i] = ddir
        else:
            out["MOS_dir2D"][i] = out["MOS_signed_minDist"][i]

        out["MOS_AP_forward"][i] = xcom[i, 0] - minx
        out["MOS_AP_backward"][i] = maxx - xcom[i, 0]
        out["MOS_AP_dir"][i] = out["MOS_AP_forward"][i] if com_vel[i, 0] < 0 else out["MOS_AP_backward"][i]

        out["MOS_ML_left"][i] = maxy - xcom[i, 1]
        out["MOS_ML_right"][i] = xcom[i, 1] - miny
        out["MOS_ML_dir"][i] = out["MOS_ML_left"][i] if com_vel[i, 1] > 0 else out["MOS_ML_right"][i]

    return pd.DataFrame(out), heeltoe_len_L, heeltoe_len_R


# -----------------------------
# Visual3D COM comparison
# -----------------------------

def compare_with_v3d_com(com: np.ndarray, v3d_com_xlsx: str) -> Tuple[pd.DataFrame, Dict[str, float]]:
    """Compare computed COM with Visual3D COM export (Excel).

    Assumes Visual3D export has 2 header rows, then columns: File, Frame, X, Y, Z.
    """
    raw = pd.read_excel(v3d_com_xlsx, header=None)
    v3d = raw.iloc[2:].copy()  # skip title row + header row
    v3d.columns = ["File", "Frame", "X", "Y", "Z"]
    v3d[["Frame", "X", "Y", "Z"]] = v3d[["Frame", "X", "Y", "Z"]].apply(pd.to_numeric, errors="coerce")
    v = v3d[["X", "Y", "Z"]].values

    if v.shape[0] != com.shape[0]:
        raise ValueError(
            f"Frame count mismatch: Visual3D COM has {v.shape[0]} frames, but pipeline produced {com.shape[0]} frames. "
            "Make sure Visual3D exported COM from the SAME trimmed window."
        )

    comp = pd.DataFrame(
        {
            "Frame": np.arange(1, com.shape[0] + 1),
            "V3D_COM_X": v[:, 0],
            "V3D_COM_Y": v[:, 1],
            "V3D_COM_Z": v[:, 2],
            "Py_COM_X": com[:, 0],
            "Py_COM_Y": com[:, 1],
            "Py_COM_Z": com[:, 2],
        }
    )
    for ax in ["X", "Y", "Z"]:
        comp[f"diff_{ax}"] = comp[f"Py_COM_{ax}"] - comp[f"V3D_COM_{ax}"]

    metrics: Dict[str, float] = {}
    for ax in ["X", "Y", "Z"]:
        metrics[f"corr_{ax}"] = float(np.corrcoef(comp[f"Py_COM_{ax}"], comp[f"V3D_COM_{ax}"])[0, 1])
        metrics[f"rmse_{ax}_m"] = float(np.sqrt(np.mean(comp[f"diff_{ax}"] ** 2)))

    return comp, metrics


# -----------------------------
# Main pipeline
# -----------------------------

def run_pipeline(
    c3d_path: str,
    event_xlsm_path: str,
    subject: str,
    leg_length: float,
    foot_length: Optional[float],
    foot_width: Optional[float],
    ankle_width: Optional[float],
    foot_length_L: Optional[float] = None,
    foot_length_R: Optional[float] = None,
    foot_width_L: Optional[float] = None,
    foot_width_R: Optional[float] = None,
    ankle_width_L: Optional[float] = None,
    ankle_width_R: Optional[float] = None,
    v3d_com_xlsx: Optional[str] = None,
    out_xlsx: Optional[str] = None,
) -> str:
    # --- Parse trial info and load events
    trial = parse_trial_info(os.path.basename(c3d_path))
    ev = load_event_info(event_xlsm_path, subject, trial.velocity, trial.trial)
    ev_local = compute_local_events(ev, pre=100, post=100)

    # --- Convert anthropometrics
    leg_m = _to_meters(leg_length, "leg")
    if leg_m is None:
        raise ValueError("leg_length is required")

    # base values (required for virtual foot)
    foot_len_base = _to_meters(foot_length, "foot_length")
    foot_w_base = _to_meters(foot_width, "foot_width")
    ankle_w_base = _to_meters(ankle_width, "ankle_width")

    if foot_len_base is None or foot_w_base is None or ankle_w_base is None:
        raise ValueError(
            "foot_length, foot_width, and ankle_width are required (anthropometrics). "
            "Provide either the base values, or left/right values."
        )

    # side overrides
    foot_len_L_m = _to_meters(foot_length_L, "foot_length") or foot_len_base
    foot_len_R_m = _to_meters(foot_length_R, "foot_length") or foot_len_base
    foot_w_L_m = _to_meters(foot_width_L, "foot_width") or foot_w_base
    foot_w_R_m = _to_meters(foot_width_R, "foot_width") or foot_w_base
    ankle_w_L_m = _to_meters(ankle_width_L, "ankle_width") or ankle_w_base
    ankle_w_R_m = _to_meters(ankle_width_R, "ankle_width") or ankle_w_base

    # --- Load and trim C3D markers
    marker_ts, labels, fs, first_frame = load_c3d_markers(
        c3d_path,
        trim_start_original_frame=ev_local.trim_start_original_frame,
        trim_end_original_frame=ev_local.trim_end_original_frame,
    )

    # --- Compute COM and XCoM
    com = compute_whole_body_com(marker_ts, labels)
    xcom, com_vel, l_used, omega0 = compute_xcom(com, fs, leg_m)

    n = com.shape[0]
    dt = 1.0 / fs
    frames = np.arange(1, n + 1)
    time_s = (frames - 1) * dt
    time_rel = (frames - ev_local.platform_onset_local) * dt
    orig_frames = ev_local.trim_start_original_frame + (frames - 1)

    support = np.array([
        _support_state(i, ev_local, ev.state) for i in range(n)
    ], dtype=object)

    base = pd.DataFrame(
        {
            "Frame": frames,
            "Time_s": time_s,
            "Time_rel_platform_onset_s": time_rel,
            "Original_frame": orig_frames,
            "Support": support,
            "Platform_onset_flag": (frames == ev_local.platform_onset_local).astype(int),
            "Platform_offset_flag": (frames == ev_local.platform_offset_local).astype(int),
            "Step_onset_flag": (frames == ev_local.step_onset_local).astype(int)
            if ev_local.step_onset_local is not None
            else 0,
            "COM_X": com[:, 0],
            "COM_Y": com[:, 1],
            "COM_Z": com[:, 2],
            "COMv_X": com_vel[:, 0],
            "COMv_Y": com_vel[:, 1],
            "COMv_Z": com_vel[:, 2],
            "XCOM_X": xcom[:, 0],
            "XCOM_Y": xcom[:, 1],
        }
    )

    # BoS/MoS
    mkr = compute_bos_mos_marker_hull(marker_ts, labels, xcom, com_vel, ev_local, ev.state)
    mkr = mkr.add_prefix("MKR_")

    virt, heeltoe_L, heeltoe_R = compute_bos_mos_virtual(
        marker_ts,
        labels,
        xcom,
        com_vel,
        ev_local,
        ev.state,
        foot_length_L_m=foot_len_L_m,
        foot_length_R_m=foot_len_R_m,
        foot_width_L_m=foot_w_L_m,
        foot_width_R_m=foot_w_R_m,
        ankle_width_L_m=ankle_w_L_m,
        ankle_width_R_m=ankle_w_R_m,
    )
    virt = virt.add_prefix("VIRT_")

    out = pd.concat([base, mkr, virt], axis=1)

    out["VIRT_L_heeltoe_len"] = heeltoe_L
    out["VIRT_R_heeltoe_len"] = heeltoe_R

    # Summary metrics
    pre_idx = np.arange(0, ev_local.platform_onset_local - 1)
    onset_idx = ev_local.platform_onset_local - 1
    if ev_local.step_onset_local is not None:
        step_end = max(onset_idx, ev_local.step_onset_local - 2)
    else:
        step_end = n - 1
    win = np.arange(onset_idx, step_end + 1)

    def safe_mean(x: pd.Series) -> float:
        return float(np.nanmean(x.values))

    def safe_min(x: pd.Series) -> float:
        return float(np.nanmin(x.values))

    summary = {
        "subject": subject,
        "c3d_file": os.path.basename(c3d_path),
        "fs_Hz": fs,
        "platform_onset_local_frame": ev_local.platform_onset_local,
        "platform_offset_local_frame": ev_local.platform_offset_local,
        "step_onset_local_frame": ev_local.step_onset_local if ev_local.step_onset_local is not None else "",
        "state": ev.state,
        "Hof_leg_length_m": l_used,
        "Hof_omega0_1_per_s": omega0,
        "foot_length_L_m": foot_len_L_m,
        "foot_length_R_m": foot_len_R_m,
        "foot_width_L_m": foot_w_L_m,
        "foot_width_R_m": foot_w_R_m,
        "ankle_width_L_m": ankle_w_L_m,
        "ankle_width_R_m": ankle_w_R_m,
        # marker-hull
        "MKR_MOS_signed_mean_pre": safe_mean(out.loc[pre_idx, "MKR_MOS_signed_minDist"]),
        "MKR_MOS_dir2D_mean_pre": safe_mean(out.loc[pre_idx, "MKR_MOS_dir2D"]),
        "MKR_MOS_AP_dir_mean_pre": safe_mean(out.loc[pre_idx, "MKR_MOS_AP_dir"]),
        "MKR_BOS_area_mean_pre_m2": safe_mean(out.loc[pre_idx, "MKR_BOS_area_m2"]),
        "MKR_MOS_signed_min_onset_to_step": safe_min(out.loc[win, "MKR_MOS_signed_minDist"]),
        "MKR_MOS_dir2D_min_onset_to_step": safe_min(out.loc[win, "MKR_MOS_dir2D"]),
        "MKR_MOS_AP_dir_min_onset_to_step": safe_min(out.loc[win, "MKR_MOS_AP_dir"]),
        # virtual-foot
        "VIRT_MOS_signed_mean_pre": safe_mean(out.loc[pre_idx, "VIRT_MOS_signed_minDist"]),
        "VIRT_MOS_dir2D_mean_pre": safe_mean(out.loc[pre_idx, "VIRT_MOS_dir2D"]),
        "VIRT_MOS_AP_dir_mean_pre": safe_mean(out.loc[pre_idx, "VIRT_MOS_AP_dir"]),
        "VIRT_BOS_area_mean_pre_m2": safe_mean(out.loc[pre_idx, "VIRT_BOS_area_m2"]),
        "VIRT_MOS_signed_min_onset_to_step": safe_min(out.loc[win, "VIRT_MOS_signed_minDist"]),
        "VIRT_MOS_dir2D_min_onset_to_step": safe_min(out.loc[win, "VIRT_MOS_dir2D"]),
        "VIRT_MOS_AP_dir_min_onset_to_step": safe_min(out.loc[win, "VIRT_MOS_AP_dir"]),
        # differences
        "DIFF(VIRT-MKR)_MOS_signed_mean_pre": safe_mean(out.loc[pre_idx, "VIRT_MOS_signed_minDist"]) - safe_mean(out.loc[pre_idx, "MKR_MOS_signed_minDist"]),
        "DIFF(VIRT-MKR)_MOS_signed_min_onset_to_step": safe_min(out.loc[win, "VIRT_MOS_signed_minDist"]) - safe_min(out.loc[win, "MKR_MOS_signed_minDist"]),
    }

    summary_df = pd.DataFrame({"metric": list(summary.keys()), "value": list(summary.values())})

    comp_df = None
    if v3d_com_xlsx:
        comp_df, comp_metrics = compare_with_v3d_com(com, v3d_com_xlsx)
        for k, v in comp_metrics.items():
            summary_df.loc[len(summary_df)] = ["COM_" + k, v]

    if out_xlsx is None:
        out_xlsx = os.path.splitext(c3d_path)[0] + "_MOS.xlsx"

    with pd.ExcelWriter(out_xlsx, engine="openpyxl") as writer:
        out.to_excel(writer, sheet_name="timeseries", index=False)
        summary_df.to_excel(writer, sheet_name="summary", index=False)
        if comp_df is not None:
            comp_df.to_excel(writer, sheet_name="COM_compare", index=False)

    return out_xlsx


def main() -> None:
    ap = argparse.ArgumentParser(description="Visual3D-style COM/XCoM/BoS/MoS pipeline (marker-only)")
    ap.add_argument("--c3d", required=True, help="Input C3D file")
    ap.add_argument("--event_xlsm", required=True, help="Event file (perturb_inform.xlsm)")
    ap.add_argument("--subject", required=True, help="Subject name as in XLSM 'platform' sheet")

    ap.add_argument("--leg_length", type=float, required=True, help="Leg length. >10 => cm assumed")

    # base anthropometrics (required)
    ap.add_argument("--foot_length", type=float, required=False, default=None, help="Foot length. >1 => mm assumed")
    ap.add_argument("--foot_width", type=float, required=False, default=None, help="Foot width. >1 => cm assumed")
    ap.add_argument("--ankle_width", type=float, required=False, default=None, help="Ankle width. >1 => cm assumed")

    # side-specific overrides (optional)
    ap.add_argument("--foot_length_L", type=float, default=None)
    ap.add_argument("--foot_length_R", type=float, default=None)
    ap.add_argument("--foot_width_L", type=float, default=None)
    ap.add_argument("--foot_width_R", type=float, default=None)
    ap.add_argument("--ankle_width_L", type=float, default=None)
    ap.add_argument("--ankle_width_R", type=float, default=None)

    ap.add_argument("--v3d_com", default=None, help="Visual3D COM export Excel for validation")
    ap.add_argument("--out", default=None, help="Output Excel path")

    args = ap.parse_args()

    # enforce anthropometrics rule: either base values OR both L/R values must be present.
    have_base = (args.foot_length is not None) and (args.foot_width is not None) and (args.ankle_width is not None)
    have_lr = (
        (args.foot_length_L is not None) and (args.foot_length_R is not None)
        and (args.foot_width_L is not None) and (args.foot_width_R is not None)
        and (args.ankle_width_L is not None) and (args.ankle_width_R is not None)
    )
    if not (have_base or have_lr):
        raise SystemExit(
            "Anthropometrics missing. Provide either: \n"
            "  (A) --foot_length --foot_width --ankle_width (base values), or\n"
            "  (B) --foot_length_L/R --foot_width_L/R --ankle_width_L/R (side-specific)."
        )

    out = run_pipeline(
        c3d_path=args.c3d,
        event_xlsm_path=args.event_xlsm,
        subject=args.subject,
        leg_length=args.leg_length,
        foot_length=args.foot_length,
        foot_width=args.foot_width,
        ankle_width=args.ankle_width,
        foot_length_L=args.foot_length_L,
        foot_length_R=args.foot_length_R,
        foot_width_L=args.foot_width_L,
        foot_width_R=args.foot_width_R,
        ankle_width_L=args.ankle_width_L,
        ankle_width_R=args.ankle_width_R,
        v3d_com_xlsx=args.v3d_com,
        out_xlsx=args.out,
    )
    print(out)


if __name__ == "__main__":
    main()
